make clean
make all
clear
./prob4_3