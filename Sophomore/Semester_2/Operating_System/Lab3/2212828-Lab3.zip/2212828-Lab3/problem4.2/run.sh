make clean
make all
clear
./aggsum 200000 20