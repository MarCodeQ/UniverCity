make clean
make all
clear
./prob3_1