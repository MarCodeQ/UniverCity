make clean
make all
./file