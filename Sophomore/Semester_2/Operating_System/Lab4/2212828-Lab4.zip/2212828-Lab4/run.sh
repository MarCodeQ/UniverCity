make clean
make all
./mypool